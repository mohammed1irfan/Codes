#!/bin/bash
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/index.html s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/3rdpartylicenses.txt s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/favicon.ico s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/main.a0c173f0488b32bb.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/main.b319a9ac43e41b18.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/main.b76edcfba62cf45c.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/main.bfa93a79c29b5c68.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/polyfills.c3336057effb08a0.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/runtime.e559b2a96ed3db36.js s3://mycloudfront-buck
aws s3 cp /home/Docker-application/Codes/S3/Hadiya-frontend/styles.ef46db3751d8e999.css s3://mycloudfront-buck
